let info = 
{
        "name" : "Marky",
        "type" : "Dog",
        "color" : "Black",
        "owner" : "JJ"

}
console.log(info)